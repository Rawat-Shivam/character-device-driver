int mainMenu();
int openFile();
int closeFile(int);


//changed due to thread
//int readFile(int);
//int writeFile(int);

void readFile(void *);
void writeFile(void *);
