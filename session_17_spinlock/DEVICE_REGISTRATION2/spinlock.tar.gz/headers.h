#include<linux/init.h>
#include<linux/fs.h>
#include<linux/cdev.h>
#include<linux/slab.h>
#include<linux/moduleparam.h>
#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/uaccess.h>
#include<linux/spinlock.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("__RAWAT_SHIVAM__");
MODULE_DESCRIPTION("__character_device_driver_for_SCULL__");

